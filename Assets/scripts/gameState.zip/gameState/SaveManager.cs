using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class SaveManager : MonoBehaviour
{
    private string saveDirectory;

    private void Awake()
    {
        saveDirectory = Application.persistentDataPath + "/Saves/";
        if (!Directory.Exists(saveDirectory))
        {
            Directory.CreateDirectory(saveDirectory);
        }
    }

    public void Save(SaveData saveData, string saveName)
    {
        string savePath = Path.Combine(saveDirectory, saveName + "_latest.json");
        string json = JsonUtility.ToJson(saveData, true);

        try
        {
            File.WriteAllText(savePath, json);
            Debug.Log($"Saved data to {savePath}");
        }
        catch (IOException e)
        {
            Debug.LogError($"Failed to save data to {savePath}: {e.Message}");
        }
    }

    public List<SaveData> LoadAllSaves()
    {
        List<SaveData> saves = new List<SaveData>();
        try
        {
            foreach (string filePath in Directory.GetFiles(saveDirectory, "*_latest.json"))
            {
                string json = File.ReadAllText(filePath);
                SaveData saveData = JsonUtility.FromJson<SaveData>(json);
                saves.Add(saveData);
            }
        }
        catch (IOException e)
        {
            Debug.LogError($"Failed to load saves: {e.Message}");
        }

        return saves;
    }

    public void DeleteSave(string saveName)
    {
        string filePath = Path.Combine(saveDirectory, saveName + "_latest.json");
        try
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
                Debug.Log($"Deleted save: {saveName}");
            }
            else
            {
                Debug.LogWarning("Save file not found: " + saveName);
            }
        }
        catch (IOException e)
        {
            Debug.LogError($"Failed to delete save {saveName}: {e.Message}");
        }
    }
}
