using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro; // Import the TextMeshPro namespace

public class SaveSelectionMenu : MonoBehaviour
{
    public SaveManager saveManager;
    public Button[] saveSlotButtons;          // Buttons for each save slot
    public Button[] deleteSlotButtons;        // Delete buttons for each save slot
    public GameObject createGamePanel;        // Panel for creating a new save
    public TextMeshProUGUI[] saveSlotTexts;   // Text components for each save slot

    private List<SaveData> allSaves;

    private void Start()
    {
        // Check for missing references and log warnings
        if (saveManager == null) Debug.LogWarning("SaveManager reference is missing.");
        if (createGamePanel == null) Debug.LogWarning("CreateGamePanel reference is missing.");
        if (saveSlotButtons == null || saveSlotButtons.Length == 0) Debug.LogWarning("Save slot buttons are not assigned.");
        if (deleteSlotButtons == null || deleteSlotButtons.Length == 0) Debug.LogWarning("Delete slot buttons are not assigned.");
        if (saveSlotTexts == null || saveSlotTexts.Length == 0) Debug.LogWarning("Save slot texts are not assigned.");

        // Only proceed if all necessary references are assigned
        if (saveManager != null && saveSlotButtons.Length > 0 && deleteSlotButtons.Length > 0 && createGamePanel != null && saveSlotTexts.Length > 0)
        {
            // Log the assignment of text components for each slot
            for (int i = 0; i < saveSlotButtons.Length; i++)
            {
                if (saveSlotButtons[i] != null)
                {
                    TextMeshProUGUI slotText = saveSlotButtons[i].GetComponentInChildren<TextMeshProUGUI>();
                    if (slotText != null)
                    {
                        saveSlotTexts[i] = slotText;
                    }
                    else
                    {
                        Debug.LogWarning($"Text component for saveSlotButton at index {i} is null");
                    }
                }
            }

            LoadSaveSlots();
        }
        else
        {
            Debug.LogError("SaveSelectionMenu initialization failed due to missing references.");
        }
    }

    private void LoadSaveSlots()
    {
        allSaves = saveManager.LoadAllSaves(); // Load saved data

        for (int i = 0; i < saveSlotButtons.Length; i++)
        {
            Button slotButton = saveSlotButtons[i];
            TextMeshProUGUI slotText = saveSlotTexts[i];
            Button deleteButton = deleteSlotButtons[i];

            if (slotButton == null)
            {
                Debug.LogWarning($"slotButton at index {i} is null");
                continue;
            }
            if (slotText == null)
            {
                Debug.LogWarning($"slotText for slotButton at index {i} is null");
                continue;
            }
            if (deleteButton == null)
            {
                Debug.LogWarning($"deleteButton at index {i} is null");
                continue;
            }

            if (i < allSaves.Count)
            {
                // Display existing save data
                SaveData saveData = allSaves[i];
                slotText.text = $"Save {i + 1}:\nDay: {saveData.playerData.currentDay}\nGold: {saveData.playerData.goldCount}";

                int saveIndex = i;  // Capture index for button click event
                slotButton.onClick.RemoveAllListeners();
                slotButton.onClick.AddListener(() => LoadGame(saveData.playerData.lastScene, saveIndex)); // Assign LoadGame method

                // Configure delete button for this save slot
                deleteButton.gameObject.SetActive(true);  // Show delete button for filled slots
                deleteButton.onClick.RemoveAllListeners();
                deleteButton.onClick.AddListener(() => DeleteSave(saveIndex));
            }
            else
            {
                // Empty slot - set text to "Create a new game"
                slotText.text = $"Save {i + 1}: Create a new game";
                int emptySlotIndex = i;
                slotButton.onClick.RemoveAllListeners();
                slotButton.onClick.AddListener(() => CreateNewSave(emptySlotIndex)); // Assign CreateNewSave method

                // Hide delete button for empty slots
                deleteButton.gameObject.SetActive(false);
            }
        }
    }

    private void CreateNewSave(int slotIndex)
    {
        string saveName = $"Save_{slotIndex + 1}";

        SaveData newSaveData = new SaveData
        {
            playerData = new PlayerData
            {
                goldCount = 0,
                currentDay = 0,
                creationDate = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                lastTimePlayed = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                lastScene = "temp_shop"  // Set to temp_shop as the first scene
            }
        };

        saveManager.Save(newSaveData, saveName);

        LoadGame(newSaveData.playerData.lastScene, slotIndex);
    }

    private void DeleteSave(int slotIndex)
    {
        string saveName = $"Save_{slotIndex + 1}";
        saveManager.DeleteSave(saveName);
        LoadSaveSlots();
    }

    private void LoadGame(string lastScene, int saveIndex)
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(lastScene);
    }
}
